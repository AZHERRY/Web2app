# 🚀 WebAPK Flutter Build Bot

Bot Telegram + Web Dashboard untuk mengubah website menjadi **APK Android** menggunakan **Flutter**.  
Project ini dijalankan menggunakan **Node.js**, **PM2**, dan **VPS Linux**.

---

# 📋 Persiapan

Sebelum menjalankan script, pastikan:

- VPS sudah aktif
- Git sudah terinstall
- Node.js & npm sudah terinstall
- PM2 sudah terinstall
- Flutter akan otomatis diinstall melalui `setup.sh`

---

# ⚙️ Konfigurasi Awal

### 1. Edit File `.env`

Buka file `.env` lalu ganti semua data dengan milik kamu.

Contoh:
BOT_TOKEN=ISI_TOKEN_BOT 
API_ID=ISI_API_ID
 API_HASH=ISI_API_HASH 
 WEB_URL=http://localhost:8081
 
 Setelah selesai **save**.

---

# 📤 Upload Project

Upload semua file project ke **repository GitHub kamu**.

Contoh repository:

https://github.com/username/repository

---

# 💻 Install di VPS

Login ke VPS menggunakan SSH lalu jalankan perintah berikut.

### 1. Masuk Folder Home
mkdir /home 
cd /home

---

### 2. Clone Repository
git clone https://github.com/username/repositoy


## Masuk ke folder project
cd namarepository

##Cek isi folder
ls

---

### 3. Extract Script (Jika ZIP)
Jika script masih dalam bentuk zip:
unzip namascript.zip

---

### 4. Install Dependencies
npm install

---

### 5. Jalankan Setup

Berikan permission pada setup.sh
chmod +x ./setup.sh

##Jalankan setup
./setup.sh

##Ikuti proses install sampai selesai.
Jika diminta konfirmasi:   Y


Lalu masukkan:

- **API ID**
- **API HASH**

Tunggu sampai proses install selesai.

---

# 🔧 Edit Konfigurasi VPS

Buka file `.env`

nano .env

Ganti bagian web local menjadi:
http://localhost:8081

Simpan dengan:
CTRL + X Y ENTER

---

# ▶️ Menjalankan Bot

Jalankan bot menggunakan **PM2**
pm2 start src/bot.js --name WebApk

---

# 📊 Perintah PM2

Melihat status bot
pm2 list

Melihat log bot
pm2 logs WebApk

Restart bot
pm2 restart WebApk

Stop bot
pm2 stop WebApk

---

# ✅ Selesai

Bot build APK sudah berjalan di VPS 🎉

Sekarang kamu bisa menggunakan bot untuk **build website menjadi aplikasi Android (APK)**.

---

# 👨‍💻 Credits

Developer & Maintainer  
@AanzCuyxzzz
Project Build System Flutter WebAPK